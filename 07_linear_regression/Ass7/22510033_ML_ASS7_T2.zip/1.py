import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

file_path = "linear_regression_3.csv"
df = pd.read_csv(file_path)

#Remove Outliers using IQR method
Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
df_iqr_clean = df[~((df < lower_bound) | (df > upper_bound)).all(axis=1)]

X_iqr = df_iqr_clean.drop(columns=['y'])
y_iqr = df_iqr_clean['y']

#Remove features with high VIF (VIF > 4)
def calculate_vif(X):
    vif_data = pd.DataFrame()
    vif_data["Feature"] = X.columns
    vif_data["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
    return vif_data

def remove_high_vif(X, vif_threshold=4.0):
    vif_data = calculate_vif(X)
    while vif_data["VIF"].max() > vif_threshold:
        high_vif_feature = vif_data.sort_values(by="VIF", ascending=False).iloc[0]["Feature"]
        X = X.drop(columns=[high_vif_feature])
        vif_data = calculate_vif(X)
    return X

X_vif_clean = remove_high_vif(X_iqr, vif_threshold=4.0)


X_vif_const = sm.add_constant(X_vif_clean)

#Detect Influence Points using Cook's Distance and DFFITS
model = sm.OLS(y_iqr, X_vif_const).fit()
influence = model.get_influence()
cooks_d, _ = influence.cooks_distance
threshold_cook = 2.8 / len(X_vif_clean)

defits_values, _ = influence.dffits
threshold_dffits = 1.1 * np.sqrt(X_vif_clean.shape[1] / len(X_vif_clean))

# Detect high influence points
high_influence_points = (cooks_d > threshold_cook) | (np.abs(defits_values) > threshold_dffits)
df_final_clean = df_iqr_clean[~high_influence_points]

# Train-Test Split 
X_final = df_final_clean.drop(columns=['y'])
y_final = df_final_clean['y']

X_train, X_test, y_train, y_test = train_test_split(X_final, y_final, test_size=0.2, random_state=42)

linear_model = LinearRegression()
linear_model.fit(X_train, y_train)

#Evaluation
y_pred = linear_model.predict(X_test)
r2_final = r2_score(y_test, y_pred)

print(f"R² Score: {r2_final:.4f}")
